import { LoadedConfigSelectors } from "@smithy/node-config-provider";
/**
 * @public
 */
export declare const NODE_AUTH_SCHEME_PREFERENCE_OPTIONS: LoadedConfigSelectors<string[]>;
