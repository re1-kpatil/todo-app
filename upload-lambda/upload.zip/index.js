// index.js
const AWS = require('aws-sdk');
const s3 = new AWS.S3();
const { v4: uuidv4 } = require('uuid');

exports.handler = async (event) => {
  try {
    const { fileContent, fileName } = JSON.parse(event.body);

    // Convert base64 to binary
    const buffer = Buffer.from(fileContent, 'base64');

    const uploadParams = {
      Bucket: 'todolistfinal', // <-- replace with your real bucket name
      Key: `${uuidv4()}-${fileName}`,
      Body: buffer,
      ContentType: "application/octet-stream",
    };

    // Upload file to S3
    await s3.putObject(uploadParams).promise();

    return {
      statusCode: 200,
      headers: { "Access-Control-Allow-Origin": "*" },
      body: JSON.stringify({ message: 'File uploaded successfully!' })
    };
  } catch (error) {
    console.error("Error uploading file:", error);
    return {
      statusCode: 500,
      headers: { "Access-Control-Allow-Origin": "*" },
      body: JSON.stringify({ message: 'Upload failed', error: error.message })
    };
  }
};
